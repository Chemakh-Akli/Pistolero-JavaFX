package ClassObjet;

public enum Touche {
    AVANCER,
    RECULER,
    GAUCHE,
    DROITE,
    PAUSE,
    TIRER;
}
